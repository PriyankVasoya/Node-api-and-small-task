var mysql = require("mysql");

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Root@123",
    database:"db_node_form"
});

module.exports = con;